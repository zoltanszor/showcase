(* input for general parametric function, default is to assume singularities are at z[i]=0, 
    for singularities at z[i]=0 and z[i]=1 add variable label i to splitlist  *) 

(* give integration variables z_1,..,z_n as a list *)

nmax=4;

intvars=Table[z[i],{i,nmax}];

(* give list of factors f[z[i]] and powers a[i] as  { {f[z], a[1]},.., {f[z], a[nmax]} }*)


(* note that parameters like beta can be left symbolic in the decomposition *)
(* numerical value only has to be specified in param.input *)

(* example is Hypergeometric5F4 *)

a1= eps;
a2=-eps;
a3=-3eps;
a4=-5eps;
a5=-7eps;
b1=2*eps;
b2=4*eps;
b3=6*eps;
b4=8*eps;


factorlist={ {Gamma[a2], -1}, {Gamma[a3], -1}, {Gamma[a4], -1},{Gamma[a5], -1}, 
 {Gamma[b1], 1}, {Gamma[b2], 1}, {Gamma[b3], 1}, {Gamma[b4], 1}, 
 {Gamma[-a2 + b1], -1}, {Gamma[-a3 + b2], -1}, {Gamma[-a4 + b3], -1}, {Gamma[-a5 + b4], -1},
 {1 - z[1], -1 - a5 + b4},  {z[1], -1 + a5}, 
 {1 - z[2], -1 - a4 + b3}, {z[2], -1 + a4}, 
 {1 - z[3], -1 - a3 + b2}, {z[3], -1 + a3}, 
 {1 - z[4], -1 - a2 + b1}, {z[4], -1 + a2}, 
 {1 - beta*z[1]*z[2]*z[3]*z[4], -a1}};

(* optional: add flag to exclude some of the functions from the decomposition as third entry 
    in the list like {f[z],a[j],n} where "n" means  exclude from the decomposition;
     NOTE that functions with powers > -1  will not be decomposed anyway;  *)
  


(* list of labels of variables which can lead to a singularity at zero AND one
    (integration will be split at 1/2 and remapped to unit interval)    *)
    
splitlist={1,2,3,4};   

(* Dimension can be changed, but symbol for dimension (Dim) and epsilon (eps) must be the same *)

Dim=4-2*eps;


