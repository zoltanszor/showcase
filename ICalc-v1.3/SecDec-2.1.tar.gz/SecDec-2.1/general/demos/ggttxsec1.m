
(* give integration variables z_1,..,z_n as a list *)

nmax=5;

(* primary secdec has been done in loop/helpggttx.m *)
(* t[6] has been renamed into t[1] *)


intvars=Table[t[i],{i,nmax}];

(*repl=Join[Table[t[i]->z[i],{i,2,5}],{t[6]->z[1]}];*)

repl={z[5]->t[5],z[6]->t[1],zm[5]->1-t[5],zm[6]->1-t[1]};

repmand={ms[1]->msq,sp[1,2]->s12,sp[1,3]->s13,sp[2,3]->s23};

(* give list of factors f[z[i]] and powers a[i] as  { {f[z], a[1]},.., {f[z], a[nmax]} }*)


(* note that parameters like beta can be left symbolic in the decomposition *)
(* numerical value only has to be specified in param.input *)

(* example is non-planar two-loop box ggtt2 with one integration already done analytically *)


Uu=(1 + t[2] + t[3] + t[4]);

Ff=(ms[1] + sp[1, 2]*t[2]*t[3] + 
   sp[1, 2]*t[2]*t[4]*z[5]*z[6] + ms[1]*t[4]*z[6]*zm[5] + 
   sp[1, 3]*t[4]*z[6]*zm[5] + ms[1]*t[4]*z[5]*zm[6] + 
   sp[2, 3]*t[4]*z[5]*zm[6] + sp[1, 2]*t[3]*t[4]*zm[5]*zm[6])/.repmand/.repl;

(* old:
Ff=(ms[1] + sp[1, 2]*t[2]*t[3] + 
   sp[1, 2]*t[3]*t[4] + ms[1]*t[4]*t[5] + sp[2, 3]*t[4]*t[5] + 
   2*ms[1]*t[3]*t[4]*t[5] + sp[1, 3]*t[3]*t[4]*t[5] + 
   sp[2, 3]*t[3]*t[4]*t[5] + ms[1]*t[4]*t[1] + sp[1, 3]*t[4]*t[1] + 
   2*ms[1]*t[3]*t[4]*t[1] + sp[1, 3]*t[3]*t[4]*t[1] + 
   sp[2, 3]*t[3]*t[4]*t[1] + sp[1, 2]*t[4]*t[5]*t[1] + 
   sp[1, 2]*t[2]*t[4]*t[5]*t[1] + sp[1, 2]*t[3]*t[4]*t[5]*t[1])/.repmand/.repl;
*)
factorlist={{t[4], 1+eps},{Uu,1+3*eps},{Ff,-3-2*eps}};

(* optional: add flag to exclude some of the functions from the decomposition as third entry 
    in the list like {f[z],a[j],n} where "n" means  exclude from the decomposition;
     NOTE that functions with powers > -1  will not be decomposed anyway;  *)
  


(* list of labels of variables which can lead to a singularity at zero AND one
    (integration will be split at 1/2 and remapped to unit interval)    *)
    
splitlist={1,5};   

(* Dimension can be changed, but symbol for dimension (Dim) and epsilon (eps) must be the same *)

Dim=4-2*eps;


