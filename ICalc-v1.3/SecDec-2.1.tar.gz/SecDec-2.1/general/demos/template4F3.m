
(* give integration variables z_1,..,z_n as a list *)

nmax=3;

intvars=Table[z[i],{i,nmax}];

(* give list of factors f[z[i]] and powers a[i] as  { {f[z], a[1]},.., {f[z], a[nmax]} }*)


(* note that parameters like beta can be left symbolic in the decomposition *)
(* numerical value only has to be specified in param.input *)

(* example is Hypergeometric4F3 *)

a1=-4eps;
a2=-1/2-eps;
a3=-3/2-2eps;
a4=1/2-3eps;
b1=-1/2+2eps;
b2=-1/2+4eps;
b3=1/2+6eps;

factorlist={{10,8},{Gamma[a2], -1}, {Gamma[a3], -1}, {Gamma[a4], -1}, 
 {Gamma[b1], 1}, {Gamma[b2], 1}, {Gamma[b3], 1}, 
 {Gamma[-a2 + b1], -1}, {Gamma[-a3 + b2], -1},{Gamma[-a4 + b3], -1},
 {1 - z[1], -1 - a2 + b1}, {z[1], -1 + a2}, 
 {1 - z[2], -1 - a3 + b2}, {z[2], -1 + a3}, 
 {1 - z[3], -1 - a4 + b3}, {z[3], -1 + a4}, 
 {1 - beta*z[1]*z[2]*z[3], -a1}};

(* optional: add flag to exclude some of the functions from the decomposition as third entry 
    in the list like {f[z],a[j],n} where "n" means  exclude from the decomposition;
     NOTE that functions with powers > -1  will not be decomposed anyway;  *)
  


(* list of labels of variables which can lead to a singularity at zero AND one
    (integration will be split at 1/2 and remapped to unit interval)    *)

(*in this example, z[3] can lead to a singularity at one but not zero,
so  remapping z[3]->1-z[3]  the splitting of z[3] at 1/2 can be avoided    *)

factorlist=factorlist/.z[3]->1-z[3];
    
splitlist={1,2};   

(* Dimension can be changed, but symbol for dimension (Dim) and epsilon (eps) must be the same *)

Dim=4-2*eps;


