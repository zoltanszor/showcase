intvars={a};
cut=1;
