intvars={a,b,c,d};

dum1=a^2 + b^3 +c^4 +d^5 + 4 a b c d +2-a^2b^3c^4d^5;
