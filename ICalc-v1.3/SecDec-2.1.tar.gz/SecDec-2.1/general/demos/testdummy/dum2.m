intvars={a,b};

dum2=a^2 + b^2 +beta^2 + 4 a b - Sqrt[a b beta]+3a^2 b^2;
