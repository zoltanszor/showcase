nmax=3;

intvars=Table[z[i],{i,nmax}];

factorlist={{z[1]+a*z[2],-1+2eps},{1+a z[1]+b z[2]+c z[3],1+eps}};

splitlist={};   

Dim=4-2*eps;


