#! /usr/bin/perl -X
#****s* SecDec/loop/decomposegeneral.pl
#
#  NAME
#  decomposegeneral.pl
#
#  USAGE
#  ./decomposegeneral.pl or ./launch
# 
#  USES 
#  $paramfile, header.pm, mathlaunch.pl
#
#  USED BY 
#  launch 
#      
#  PURPOSE
#  doing the iterated sector decomposition in Mathematica in the case 
#  where no primary sector decomposition was done but integrands were
#  inserted by the user via the template file.
#  Uses a different decomposition strategy if infinite recursion occurs
#  the primary sectors for which a different strategy should be used 
#  must be given at the end of the $paramfile
#    
#  INPUTS
#  $paramfile (default is paramgeneral.input), read via module header
#  $templatefile (default is templategeneral.m)
#    
#  RESULT    
#  -adds decomposition part to the file $currentdir/$graph.m 
#  -launches the decomposition and writes the results to 
#   $currentdir in the form of lists containing the 
#   parametric functions for each pole structure
#  OPTIONS
#  to use a paramgeneral.input file with a different name
#  use option "-p paramfile" 
#  to use a template file with the a different name
#  use option "-t templatefile"
#  to specify a different directory to work in
#  use option "-d workingdirectory" 
# 
#****
##################################
use Getopt::Long;
GetOptions("parameter=s" => \$paramfile, "template=s"=>\$templatefile, "dirwork=s"=>\$workingdir);
unless ($paramfile) {
  $paramfile = "paramgeneral.input";
}
unless ($templatefile) {
  $templatefile = "templategeneral.m";
}
$wparamfile=$paramfile;
if($workingdir){
 $workingdir=~s/\/$//;
 $wparamfile="$workingdir/$paramfile";
 $templatefile="$workingdir/$templatefile";
 $absdir=1;
 $wdstring=" -d $workingdir";
}
use lib "perlsrc";
use header;
use getinfo;
use dirform;
unless(-e $wparamfile){die "$wparamfile does not exist\n"};
system("perl -pi -e 's/\\/(\\s*)\\n/\\n/g' $wparamfile");
my %hash_var=header::readparams($wparamfile);
header::printversion();
########## loop or general function #########################
#$integrandtype=$hash_var{"integrandtype"};
#unless ($integrandtype) {$integrandtype="loop"};
#if ($integrandtype eq "Loop"){$integrandtype="loop"};
#if ($integrandtype eq "General"){$integrandtype="general"};
#############################################################
$dirbase=`pwd`;
chomp $dirbase;
$subdir=$hash_var{"diry"};
$diry=dirform::norm("${dirbase}/$subdir");
$currentdir=$hash_var{"currentdir"};
$graph=$hash_var{"graph"};
print "graph = $graph\n";
print "\nNo primary sector decomposition is done.\n\n";
$exe=$hash_var{"exe"};
if($exe ne "0"){unless($exe){$exe=4}};
$contourdef=$hash_var{"contourdef"};
if ($contourdef eq "true"){$contourdef="True"};
if ($contourdef eq "false"){$contourdef="False"};
$rescaleflag=$hash_var{"rescaleflag"};
$clusterflag=$hash_var{"clusterflag"};
unless($clusterflag){$clusterflag=0};
unless($graph){die "must give the graph name in $paramfile\n"};
$together=$hash_var{"together"};
$fromlaunch=$ARGV[0];
unless($fromlaunch){$fromlaunch=""};
if ($fromlaunch ne "launch") {
print "graph = $graph\n";
}
$externalegs=$hash_var{"externalegs"};
$cutconstruct=$hash_var{"cutconstruct"};
$loops=$hash_var{"loops"};
if ($currentdir) {
    $absdir=1;
} else {
    if($workingdir) {
	if ($workingdir=~m/^\//){
	    $diry=dirform::norm("$workingdir/$subdir");
	    $currentdir="$diry/$graph";
	} else {
	    $subdir="$workingdir/$subdir";
	    $diry=dirform::norm("${dirbase}/$subdir");
	    $currentdir="$diry/$graph";
	}
    } else {
	$currentdir=dirform::norm("$diry/$graph");
    }
}
$feynpars=$hash_var{"feynpars"};
$Nn=$hash_var{"Nn"};
$Nmin=1;
$Nmax=$Nn;
@Nlist = split(/,/,$hash_var{"Nlist"});
$indflag=0;
if (@Nlist){
 $indflag=1
}else{
 print "results of the decomposition will be written to\n";
 print "$currentdir\n";
}
unless (@Nlist) {
@Nlist=($Nmin .. $Nmax)
};
$Nmin=$Nlist[0];
$last=eval(@Nlist-1);
$Nmax=$Nlist[$last];
@multiplicities = split(/,/,$hash_var{"multlist"});
unless (@multiplicities) {
@multiplicities = (1,@Nlist);
}
$el=0;
foreach $sec (@Nlist) {
if (@multiplicities) {
$hashmulti{ $sec } = $multiplicities[$el];
}
else{
$hashmulti{ $sec } = 1;
}
$el++;
}
@nonstoplist = split(/,/,$hash_var{"nonstop"});
$nbnonstop=@nonstoplist;
#
############## end of user defined input #############################
#
######### BEGIN create directory structure ###########################
if ($absdir) {
    unless(-d $currentdir) {
	@desdir=split(/\//,$currentdir);
	$dstring="";
	foreach $dirbit (@desdir) {
	    if($dirbit) {
		$dstring="$dstring/$dirbit";
		unless($dstring eq "/") {
		    unless (-d $dstring) {
			system("mkdir $dstring");
			$mkerr=$?>>8;
			unless($mkerr==0) {
			    die "could not create directory $dstring\n";
			} } } } } }
} else {
    if ($subdir) {
	unless ( -e "$subdir") {
	    system ("mkdir -p $subdir");
	}
	chdir("$subdir") || die "cannot change to directory $subdir\n"; 
    }
    unless ( -e "$graph") {
	system ("mkdir  $graph");
    }
    chdir("$dirbase") || die "cannot change to directory $dirbase\n";
}
######### END create directory structure #############################
######################################################################
######### BEGIN change template.m 
$itermax=1;
if ($indflag==1){
 $itermax=@Nlist;
 open (ALLSEC,">","decompose$graph");
 print ALLSEC "echo \"results of the decomposition will be written to\"\n";
 print ALLSEC "echo \"$currentdir\"\n";
};
for ($iti=0;$iti<$itermax;$iti++) {
    if($indflag==1){$Nmin=$Nlist[$iti];$Nmax=$Nmin};
    $primlist=0;
    open (EREAD,"$templatefile") || die "cannot open $templatefile\n";
    open (ET,">tmp$graph") || die "cannot open tmp$graph\n";
    while(<EREAD>) {
	chomp;
############ check: is primseclist specified in template file ##############
	if ( $_ =~ /primseclist/ ) { $primlist=1; }
	print ET "$_\n";
    }
    close (EREAD);
    unless ($primlist) { die "cannot find user inserted list with functions which need no primary sector decomposition\n"; }
    $templatetail="$dirbase/src/deco/templatetail_general.m";
    open (EREAD,"$templatetail") || die "cannot open $templatetail\n";
    while(<EREAD>) {
	chomp;
	s/path\s*=\s*(.*)/path=\"$dirbase\/\"/;
	s/graphstring\s*=\s*ToString\[\w.*\]\s*/graphstring="$graph"/;
########## integrandtype is ==False for general functions ############
#	s/integrandtype\s*=\s*\w*/integrandtype=False/;
######################################################################
### define Nn to be consistent with loop branch: ###
	s/Nn\s*=\s*\d*/Nn=$Nn/;
	s/feynpars\s*=\s*\d*/feynpars=$feynpars/;
	s/externalegs\s*=\s*\d*/externalegs=$externalegs/;
	s/loops\s*=*\d*/loops=$loops/;
#	s/externalegs\s*=\s*\d*\;//;
#	s/loops\s*=\s*\d*\;//;
	s/currentdir\s*=\s*(.*)/currentdir=\"$currentdir\/\"/;
#	s/npmin\s*=\s*(\d.*)/npmin=${Nmin};/;
#	s/npmax\s*=\s*\d*/npmax=Min\[${Nmax},Length\[primseclist\]\]/; SB 17.9.12: later: exchange by Min[certain number of functions of primseclist,length(primseclist)]
	s/npmin\s*=\s*\d*/npmin=Min\[Table\[primseclist\[\[nf,1\]\],\{nf,1,Length\[primseclist\]\}\],Length\[primseclist\]\]/; #last check is for when primseclist is empty or contains 1 function with arbitrary number (e.g. 10) instead of {1,{},{{U,,},{F,,}},}
	s/npmax\s*=\s*\d*/npmax=Max\[Table\[primseclist\[\[nf,1\]\],\{nf,1,Length\[primseclist\]\}\]\]/;
	s/rescaleflag\s*=\s*\d*/rescaleflag=${rescaleflag}/;
	print ET "$_\n";
    }
    close (EREAD);

    print ET "xl=loops;\n"; ###to be consistent with loop branch
    print ET "If[MatchQ[F[z],0],\n";
    print ET "Print[\"Warning, F[z]=0, please verify your input\"];\n";
    print ET ",\n";
#    print ET "signcheck={z[a_]->1/2,ssp[b_]->-1,sp[c__]->-1,ms[d_]->1};\n";
#    if ($contourdef eq "True") {
#	print ET "If[False,\n";
#    } else {
#	print ET "If[(F[z]/.signcheck)<0,\n";
#    }
#    print ET "Print[\"Warning, F[z] is not positive semi-definite, please verify your input\"];\n";
#    print ET ",\n";
    print ET "(* prepare the input for decomposition *)\n";
    print ET "\n";
    print ET "Get[StringJoin[path,ToString[\"src/deco/prepareinput.m\"]]];\n";
    print ET "\n";
    print ET "(* do the iterated decomposition *)\n";
    print ET "\n";
    $qlist=join(",",@nonstoplist);
    print ET "qlist=\{$qlist\};\n";
    print ET "Get[StringJoin[path,ToString[\"src/deco/deconoprimary.m\"]]];\n";
    print ET "\n";
    print ET "];\n";  
#    print ET "]];\n";  
    close (ET);
    
#####################################################
    chdir("$dirbase") || die "cannot change to directory $dirbase\n";
    $logex="";
    if($Nmin==$Nmax) {$logex="Sec$Nmin"; $logexflag=1;}
    if($logexflag) {system("cp $dirbase/tmp${graph} $currentdir/${graph}.m"); }
    system("mv $dirbase/tmp${graph} $currentdir/${graph}$logex.m");
    if($indflag==0) {
	print "doing sector decomposition . . . \n";
	system ("perl perlsrc/mathlaunch.pl $currentdir/${graph}$logex.m $currentdir/${graph}Decomposition$logex.log");
	$wflag=getinfo::decwarning("$currentdir/${graph}Decomposition$logex.log");
	if($wflag==0){
	    print "done\n";
	} else {
	    print "Error in F[z]. Please check your input, in particular the on-shell conditions\n";
	    exit 10;
	}
    } else {
	open (SECLAUNCH,">","$currentdir/launch${graph}$logex");
	print SECLAUNCH "cd $dirbase\n";
	print SECLAUNCH "if [ ! \$1 ]\nthen\n";
	print SECLAUNCH "echo \"results of the decomposition will be written to\"\n";
	print SECLAUNCH "echo \"$currentdir\"\n";
	print SECLAUNCH "echo \"Decomposing $logex\"\nfi\n";
	print SECLAUNCH "perl perlsrc/mathlaunch.pl $currentdir/${graph}$logex.m $currentdir/${graph}Decomposition$logex.log";
	close (SECLAUNCH);
	system("chmod +x $currentdir/launch${graph}$logex");
	print ALLSEC "echo \"Decomposing $logex\"\n";
	print ALLSEC "$currentdir/launch${graph}$logex 1\n";
    }
} # end for ($iti=0;$iti<$itermax;$iti++)
if ($indflag==1) {
    print ALLSEC "cd $dirbase\n";
    print ALLSEC "./subexpgeneral.pl -p $paramfile$wdstring\n";
    print ALLSEC "echo\necho\n";
    if($exe-$clusterflag==4) {
	print ALLSEC "./resultsgeneral.pl -p $paramfile$wdstring\n";
    } elsif($exe==4) {
	print ALLSEC "echo \"When all jobs are completed, cd to \"\n";
	print ALLSEC "echo \"$dirbase\"\n";
	print ALLSEC "echo \"and run resultsgeneral.pl -p $paramfile$wdstring\"\n";
    } else {
	if($clusterflag==0) {
	    print ALLSEC "echo \"to complete the calculation, cd to\"\n";
	    print ALLSEC "echo \"$dirbase\"\n";
	    print ALLSEC "echo \"and run finishnumericsgeneral.pl -p $paramfile$wdstring\"\n";
	} elsif($exe==0) {
	    print ALLSEC "echo \"to complete the calculation, cd to\"\n";
	    print ALLSEC "echo \"$dirbase\"\n";
	    print ALLSEC "echo \"and run finishnumericsgeneral.pl -p $paramfile$wdstring\"\n";
	} else {
	    if($together==0) {
		print ALLSEC "echo \"to complete the calculation, wait for all jobs to finish, then cd to\"\n";
		print ALLSEC "echo \"$dirbase\"\n";
		print ALLSEC "echo \"and run finishnumericsgeneral.pl -p $paramfile$wdstring\"\n";
	    }
	}
    }
    ;
    close ALLSEC;
    system("chmod +x decompose$graph");
    print "To run the decomposition in series, type '$dirbase/decompose$graph'\n";
    print "To distribute decomposition over a number of cores, run the executables\n";
    print "$currentdir/launch${graph}Sec*\n";
    print "after the decomposition is done, cd to $dirbase and type\n './subexpgeneral.pl -p $paramfile$wdstring'\n";
    print "(This is done automatically when run in series)\n";
    print "to collect the results, type './resultsgeneral.pl -p $paramfile$wdstring'\n";
} 
print "\n"; 
#####################################################




################from makeFU.pl#####################################################################
###############
#################NEW STUFF
############## end of user defined input #############################
#
######### BEGIN insert main path in template.m for general case ######

#    print ET "If[cutconstruct,\n";
#    print ET " fun=calcFUcut[proplist,externalegs,loops,onshell],\n";
#    print ET " fun=calcFU[momlist,proplist,numerator,onshell,externalegs]];\n";
#    print ET "U[z_]:=fun[[1]];\n";
#    print ET "F[z_]:=fun[[2]];\n";
#    print ET "Nu[z_]:=Product[z[i]^Simplify[powerlist[[i]]-1], {i,Nn}]*fun[[3]];\n";
#    print ET "rank=fun[[4]];\n";
#    print ET "If[F[z]==0, Print[\"Warning, function F is zero, please check your on-shell conditions\"]];\n";
#    print ET "\n";
#    print ET "funfile=StringJoin[currentdir,\"/FUN.m\"];\n";
#    print ET "OpenWrite[funfile];\n";
#    print ET "WriteString[funfile,\"U[z_]:=\"];\n";
#    print ET "Write[funfile,U[z]];\n";
#    print ET "WriteString[funfile,\"\\n\"];\n";
#    print ET "WriteString[funfile,\"F[z_]:=\"];\n";
#    print ET "Write[funfile,F[z]];\n";
#    print ET "WriteString[funfile,\"\\n\"];\n";
#    print ET "WriteString[funfile,\"Nu[z_]:=\"];\n";
#    print ET "Write[funfile,Nu[z]];\n";
#    print ET "WriteString[funfile,\"\\n\"];\n";
#    print ET "WriteString[funfile,\"rank=\"];\n";
#    print ET "Write[funfile,rank];\n";
#    print ET "WriteString[funfile,\"\\n\"];\n";
#    print ET "Close[funfile];\n";
##    close (ET);
##    close (EREAD);
#
######### END insert main path in template.m for general case ########
######################################################################

