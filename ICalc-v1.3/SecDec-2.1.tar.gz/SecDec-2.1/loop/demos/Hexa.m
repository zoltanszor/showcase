
(* USER INPUT: *)

Nn=6;
 
(* 1loop massless hexagon  *)

proplist={{0,{1,2}},{0,{2,3}},{0,{3,4}},{0,{4,5}},{0,{5,6}},{0,{6,1}}};

numerator={1};

powerlist=Table[1,{i,Length[proplist]}];

onshell=Join[Table[ssp[i]->0,{i,Nn}],Table[ms[i]->0,{i,Nn}]];

(* note that in constructing F, (pi+pj)^2 will automatically be called sp[i,j]; 
    pi^2 will be called ssp[i];
    masses m_i^2 must be called ms[i];  *)


(* Dim can be changed, but symbol for epsilon must be the same *)
Dim=4-2*eps;


 
