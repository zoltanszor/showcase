#! /usr/bin/perl -X
#****s* SecDec/loop/dotogether.pl
# NAME
#  dotogether.pl
# USAGE
# './dotogether.pl ord1 ord2 ord3 ...'
# PURPOSE
#  integrates all integrands for the specified order of epsilon
#  as one function, instead of individually integrating different
#  pole structures and numbers of integration variables separately.
#  this is particularly useful when intermediate calculations produce
#  large positive and negative outputs, which cancel to give a small
#  final result. NB if specifying a negative order, this must be expressed
#  as 'm1', instead of '-1'.
#  OPTIONS
#  to use a parameter file with a different name
#  use option "-p paramfile" 
#  to specify a different directory to work in
#  use option "-d workingdirectory" 
#****
use lib "perlsrc";
use header;
use getinfo;
use makeint;
use launchjob;
use makejob;
use dirform;
use Getopt::Long;
GetOptions("parameter=s" => \$paramfile, "template=s"=>\$templatefile, "dirwork=s"=>\$workingdir);
unless ($paramfile) {
  $paramfile = "paramloop.input";
}
unless ($templatefile) {
    $templatefile = "templateloop.m";
}
$wdstring="";$wparamfile=$paramfile;
if($workingdir){
    $workingdir=~s/\/$//;
    $wdstring="-d=$workingdir ";
    $wparamfile="$workingdir/$paramfile";
    $templatefile="$workingdir/$templatefile"
}
my %hash_var=header::readparams($wparamfile);
############## BEGIN language (Cpp,Fortran) specific parameters ###########
my $language=$hash_var{"language"};
unless ($language) {$language="cpp"};
if($language eq "Fortran"){$language="fortran"};
if ($language eq "fortran"){$suf=".f"}else{$suf=".cc"};
$compiler=$hash_var{"compiler"};
unless ($compiler) {$compiler="gfortran"};

$contourdef=$hash_var{"contourdef"};
unless ($contourdef) {$contourdef="False"};
if ($contourdef eq "true"){$contourdef="True"};
############## END language (Cpp,Fortran) specific parameters #############

my @epsord=@ARGV;
@Nlist = split(/,/,$hash_var{"Nlist"});
$Nn=$hash_var{"Nn"};
$Nmin=1;
$Nmax=$Nn;
@Nlist = split(/,/,$hash_var{"Nlist"});
$indflag=1;
@multiplicities = split(/,/,$hash_var{"multlist"});
$indflag=0;
if (@Nlist){$indflag=1};
unless (@Nlist) {
    $indflag=0;
    @Nlist=($Nmin .. $Nmax);
    unless (@multiplicities) {
	@multiplicities = (1,@Nlist);
    }
}
$Nmin=$Nlist[0];
$last=eval(@Nlist-1);
$Nmax=$Nlist[$last];

$el=0;
foreach $sec (@Nlist) {
    if (@multiplicities) {
	$hashmulti{ $sec } = $multiplicities[$el];
    }
    else{
	$hashmulti{ $sec } = 1;
    }
    $el++;
}
$dirbase=`pwd`;
chomp $dirbase;
$compiler=$hash_var{"compiler"};
$exe=$hash_var{"exe"};
if ($exe ne "0"){unless($exe){$exe=4}};
unless ($compiler) {$compiler="gfortran"};
$makefile="Makefile.linux";
$subdir=$hash_var{"diry"};
$diry=dirform::norm("${dirbase}/$subdir");
$currentdir=$hash_var{"currentdir"};
$graph=$hash_var{"graph"};
$clusterflag=$hash_var{"clusterflag"};
$batchsystem=$hash_var{"batch"};
$maxtime=$hash_var{"cputime"};
unless($maxtime){$maxtime=1000};
unless ($currentdir) {
if($workingdir){
if ($workingdir=~m/^\//){
  $diry=dirform::norm("$workingdir/$subdir");
  $currentdir="$diry/$graph";
 } else {
  $subdir="$workingdir/$subdir";
  $diry=dirform::norm("${dirbase}/$subdir");
  $currentdir="$diry/$graph"
 }
} else {
 $currentdir="$diry/$graph"
}
}
$basespath=$hash_var{"basespath"};
unless ($basespath) {$basespath="$dirbase/basesv5.1"};
$basespath=~s/\/loop\//\//;
$basespath=~s/\/general\//\//;
$cubapath=$hash_var{"cubapath"};
unless ($cubapath) {$cubapath="$dirbase/Cuba-3.0"};
$cubapath=~s/\/loop\//\//;
$cubapath=~s/\/general\//\//;
$routine=$hash_var{"integrator"};
unless($routine){$routine=3};
$integpath=$basespath;
if($routine){$integpath=$cubapath;$makefile="makefile"};
$point=$hash_var{"pointname"};
$filepoint=$point;
$filepoint=~s/DEFAULT//;
$maxvar=$hash_var{"Nn"}-1;
$maxord=$hash_var{"epsord"};
if($clusterflag==0){system("perl perlsrc/remakebases.pl $integpath $compiler none $compiler $makefile $routine")};


unless(-d "$currentdir/together"){system("mkdir $currentdir/together")}; 
if($indflag==0) {
    $infofile="$currentdir/${graph}OUT.info";
    if(-e $infofile){
	@poleslist=getinfo::poles($infofile);
	$prefacord=getinfo::prefacord($infofile);
	if($prefacord==-1){$maxord++}
    } 
    else { die "Could not find $infofile\n"; }
} 
else {
    @poleslist=();
    $prefacord=getinfo::prefacord("$currentdir/${graph}Sec$Nlist[0]OUT.info");
    if($prefacord==-1){$maxord++};
    foreach $sec (@Nlist){
	$infofile="$currentdir/${graph}Sec${sec}OUT.info";
	@tpolelist=getinfo::poles($infofile);
	foreach $tpole (@tpolelist){
	    $tpole="sec${sec}P$tpole";
	    push(@poleslist,$tpole)
	}
    }
}

$ominpole=0;
open (INFO,">","$currentdir/together/infofile") || die "cannot open $currentdir/together/infofile\n";
foreach $ord (@epsord) {
    $ord=~s/m/-/;
    if($ord<=$maxord) {
	@makelist=();
	@namelist=();
	foreach $polestruct (@poleslist) {
	    if ($polestruct=~/(\d+)l(\d+)h(\d+)/){$i=$1;$j=$2;$h=$3};
	    $minpole=-$i-$j-$h;
	    if($minpole<$ominpole){$ominpole=$minpole};
	    if($ord>=$minpole){
		$functdir="$currentdir/$polestruct/epstothe$ord";
		$prestring="P$polestruct";
		increaselists($functdir,$prestring)
	    }
	}
	if (@makelist){
	    $numoffuns=@namelist;
	    print INFO "\"${ord}functions = $numoffuns\"\n";
	    unless(-d "$currentdir/together/epstothe$ord"){system("mkdir $currentdir/together/epstothe$ord")};
	    if($clusterflag==1){$integpatht="$integpath/$graph/epstothe$ord"}else{$integpatht="$integpath/$compiler"};
	    if($language eq "fortran"){
		writemakefile("$currentdir/together/epstothe$ord/make$point");
		writesumfile("$currentdir/together/epstothe$ord/fullsum$point.f");
		#@intargs=(filename,order,kk,numvar,maxpole,param,integrand);
		$intfile="$currentdir/together/epstothe$ord/${point}intfile.f";
		$kk=1;
		$integrand="fullsum$point";
		@intargs=($intfile,$ord,$kk,$maxvar,$ominpole,$wparamfile,$integrand,$routine);
		makeint::go(@intargs);
		if ($clusterflag==1){
		    open(EXEFILE,">","$currentdir/together/epstothe$ord/subexe");
		    print EXEFILE "perl $dirbase/perlsrc/remakebases.pl $integpath $graph epstothe$ord $compiler $makefile $routine\n";
		    print EXEFILE "make -s -j -f make$point\n";
		    print EXEFILE "if [ \$? -ne 0 ]\n";
		    print EXEFILE "then\n";
		    print EXEFILE "  make -s -j -f make$point clean\n";
		    print EXEFILE " make -s -j -f make$point\n";
		    print EXEFILE "fi\n";
		    if($exe!=3){print EXEFILE "./${point}intfile.exe"};
		    close EXEFILE;
		    system("chmod +x $currentdir/together/epstothe$ord/subexe");
		    @jobargs=($batchsystem,"$currentdir/together/epstothe$ord/togsub","$currentdir/together/epstothe$ord","subexe",$maxtime,1);
		    makejob::go(@jobargs);
		    if($exe!=2){
			print "submitting job for integration at order eps^$ord\n";
			launchjob::submit($batchsystem,"$currentdir/together/epstothe$ord/togsub")
		    };
		    if($exe==3){
			@jobargs=($batchsystem,"$currentdir/together/epstothe$ord/togsubint","$currentdir/together/epstothe$ord","${point}intfile.exe",$maxtime,1);
			makejob::go(@jobargs)
		    }
		    
		} else {
		    $syststr="";
		    if($exe!=2){
			$syststr="cd $currentdir/together/epstothe$ord;echo compiling functions needed for calculation at order eps^$ord...;make -s -f make$point";
			$syststr="$syststr;if [ \$? -ne 0 ]; then  make -s -f make$point clean;make -s -f make$point; fi";
			if($exe!=3){
			    $syststr="$syststr;echo performing integration...;./${point}intfile.exe>${point}intfile.log"
			}
		    }
		    if ($syststr ne ""){
			system("$syststr");
			$texcode=$?>>8;
			unless($texcode==0){
			    exit $texcode
			}
		    }
		}
	    }
	    else { #if language = Cpp
		$Ccompiler="gcc";##############################################################
		$minf=$ominpole;
		$maxf=$maxvar;
		if($clusterflag==1){$integpathstring="$graph/$polestruct"}else{$integpathstring=$compiler};
				
		@makeargs=("$currentdir/together/epstothe$ord/${filepoint}make${kk}file","$integpath/$integpathstring",$Ccompiler,$point,$kk,$minf,$maxf,$currentdir,"$dirbase/src/util",$contourdef);
		writefiles::makemakeC(@makeargs);
		#$prestring="P$polestruct";
		#if ($ARGV[1]<$Nn) {$prestring="${prestring}N$numvar"};
		@intargs=("$currentdir/together/epstothe$ord/${filepoint}intfile$kk$suf",$minf,$maxf,$prestring,$ord,$kk,$Nn,$minpole,$wparamfile,"$dirbase/src/util");
		writefiles::makeintC(@intargs);
		if ($clusterflag==1) {
		    if ($ARGV[1]<$Nn) {
			if ($filepoint ne "") {
			    $jobfilename="$currentdir/$polestruct.${point}.$jj.$numvar.$kk";
			} else {
			    $jobfilename="$currentdir/$polestruct.$jj.$numvar.$kk";
			}
		    } else {
			if ($filepoint ne "") {
			    $jobfilename="$currentdir/$polestruct.${point}.$jj.$kk";
			} else {
			    $jobfilename="$currentdir/$polestruct.$jj.$kk";
			}
		    }
		    @jobargs=($batchsystem,$jobfilename,$currentdir,"${filepoint}intfile$kk.exe",$cputime,1);
		    writefiles::makejob(@jobargs); #creates job submission files
		}
	    }
	}
    } else {
	print "$ord is larger than the maximum expected order, integration will not take place at this order\n"
    }
}
close INFO;




sub increaselists {
    my $fdr=$_[0];
    my $pref=$_[1];
    $ili=1;
    while (-e "$fdr/f$ili${suf}"){
	$tfina="$fdr/f$ili.o";
	$tfuna="${pref}f$ili";
	push(@makelist,$tfina);
	push(@namelist,$tfuna);
	$ili++;
    }
}

sub writemakefile {
my $filename=$_[0];
my $funlisto="";
foreach $fun (@makelist){
 $funlisto = "$funlisto\\\n	$fun"
}
$funlisto = "$funlisto\\\n      fullsum${point}\.o";
open(MAKEFILE, ">", "$filename") || die "cannot open $filename\n";
	print MAKEFILE "FC	= $compiler\n";
if($routine==0){
	print MAKEFILE "FFLAGS	= -O\n";
	print MAKEFILE "LINKER	= \$(FC)\n";
	print MAKEFILE "GRACELDIR	= $integpatht\n";
	print MAKEFILE "BASESLIB	= bases\n";
	print MAKEFILE "\%\.o \: \%\.f\n";
	print MAKEFILE "	\$(FC) -c -o \$\@ \$(FFLAGS) \$<\n";
	print MAKEFILE "MAIN	= ${point}intfile.o\n";
	print MAKEFILE "FFILES	=$funlisto\n";
	print MAKEFILE "${point}intfile: \$(MAIN)  \$(FFILES)\n";
		
	print MAKEFILE "	\$(LINKER) \$(LDFLAGS) -o \$\@\.exe \$^";
	print MAKEFILE " \\\n";
	print MAKEFILE "	-L\$(GRACELDIR) -l\$(BASESLIB) \\\n";
	print MAKEFILE "	\$(LIB) \$(LIBS)";
	print MAKEFILE "\n";
}else{
	print MAKEFILE "FFLAGS	= -g -O2\n";
	print MAKEFILE "LIBS	= -lm\n";
	print MAKEFILE "LIB	= $integpatht/libcuba.a\n";
	print MAKEFILE "%.o : %.f\n";
	print MAKEFILE "	\$(FC) -c -o \$@ \$(FFLAGS) \$<\n";
	print MAKEFILE "MAIN	= ${point}intfile.o\n";
	print MAKEFILE "FFILES	= $funlisto\n";
	print MAKEFILE "${point}intfile: \$(MAIN)  \$(FFILES) \$(LIB)\n";
	print MAKEFILE "	 \$(FC) \$(FFLAGS) -o \$@.exe \\\n";
	print MAKEFILE "	\$(MAIN) \$(FFILES) \$(LIB) \$(LIBS)\n";
	print MAKEFILE "\n";
}


	print MAKEFILE "clean:\n";
	print MAKEFILE "	rm \$(MAIN)  \$(FFILES)\n";
close MAKEFILE;
}

sub writesumfile {
my $filename=$_[0];
my $sp="      ";
my $funlist="";
my $asslist = "";
my $gnum=0;
my $maxfuns=@namelist;
my $lineflag=0;
foreach $fun (@namelist){
	$gnum++;
	$lineflag++;
	if($gnum==$maxfuns){
		$funlist = "$funlist $fun\n";
	}elsif($lineflag >2){
		$lineflag=0;
		$funlist = "$funlist\n     # $fun,";
	} else {
		$funlist = "$funlist $fun,";
	}
	if ($indflag==1){
	 if ($fun=~m/sec(.+)P/){
	  $thisord=$1
	 }
	 if($hashmulti{$thisord}>1){$multistring="$hashmulti{$thisord}.d0*"}else{$multistring=""};
	} else {
	 $multistring="";
	}
	
	  
	$asslist = "$asslist\n$sp g($gnum) = $multistring$fun(x)";
}

open(SUMFILE, ">", "$filename");
	print SUMFILE "${sp}double precision function fullsum$point(x)\n";
	print SUMFILE "${sp}double precision x\n";
	print SUMFILE "${sp}double precision g,sumg\n";
	print SUMFILE "${sp}integer ndi\n";
	print SUMFILE "${sp}common/ndimen/ndi\n";
	print SUMFILE "${sp}parameter (nfun=$gnum)\n";
	print SUMFILE "${sp}dimension x(ndi),g(nfun)\n";
	print SUMFILE "${sp}double precision $funlist";
	print SUMFILE "${sp}$asslist\n";
	print SUMFILE "${sp}sumg = 0.D0\n";
	print SUMFILE "${sp}do k=1,nfun\n";
	print SUMFILE "${sp}sumg = sumg+g(k)\n";
	print SUMFILE "${sp}enddo\n";
	print SUMFILE "${sp}fullsum$point = sumg\n";
	print SUMFILE "${sp}return\n";
	print SUMFILE "${sp}end";
close SUMFILE;
}
