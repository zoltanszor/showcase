#! /usr/bin/perl -X
#****s* SecDec/general/multinumericsgeneral.pl
#
#  NAME
#  multinumericsgeneral.pl
#
#  USAGE
#  ./multinumericsgeneral.pl 
# 
#  PURPOSE
#  Automates the calculation of multiple numeric points for a given integrand
#    
#  INPUTS
#  multiparameter file (default is multiparamgeneral.input)
#    
#  RESULT    
#  -produces an input file for each specific point 
#  -runs/submits to a batch system the numerical integration for each point 
#  
#  OPTIONS
#  to use a multiparameter file with a different name
#  use option "-p multiparamfile" 
#  to specify a different directory to work in
#  use option "-d workingdirectory" 
#  to collect results files (only required when run on the batch system), run with
#   argument "1"
#  to remove all derived paramfiles, run with the argument "2", eg
#   ./multinumericsgeneral.pl -d demos/ -p multi.input 2
#
# 
#****
use Getopt::Long;
GetOptions("parameter=s" => \$multiparam, "dirwork=s"=>\$workingdir);
unless ($multiparam) {
  $multiparam = "multiparamgeneral.input";
}
$mparam=$multiparam;
if($workingdir){
 $workingdir=~s/\/$//;
 $mparam="$workingdir/$multiparam";
 $absdir=1;
}
unless($workingdir){$workingdir=`pwd`;chomp $workingdir}
use lib "perlsrc";
use header;
use getinfo;
use dirform;

my %hash_var=readmultiparams($mparam);
$paramfile=$hash_var{"paramfile"};
$linenumbers=$hash_var{"lines"};
$prefix=$hash_var{"pointname"};
unless($prefix){$prefix="np"};
$nsij=$hash_var{"numsij"};
$npi2=$hash_var{"numpi2"};
$nms2=$hash_var{"numms2"};
$ninv=$nsij+$npi2+$nms2;
@xplot=split(/,/,$hash_var{"xplot"});
if(@xplot){
 $plotting=1;
 $numxplot=@xplot;
 for($i=0;$i<$numxplot;$i++){
  $xplot[$i]=$xplot[$i]-1
 }
};
$flag=$ARGV[0];
$pointscalculated=0;
my %hash1_var=header::readparams("$workingdir/$paramfile");

$dirbase=`pwd`;
chomp $dirbase;
$subdir=$hash1_var{"diry"};
$diry=dirform::norm("${dirbase}/$subdir");
$currentdir=$hash1_var{"currentdir"};
$graph=$hash1_var{"graph"};
unless ($currentdir) {
    if($workingdir) {
	if ($workingdir=~m/^\//) {
	    $diry=dirform::norm("$workingdir/$subdir");
	    $currentdir="$diry/$graph";
	} else {
	    $subdir="$workingdir/$subdir";
	    $diry=dirform::norm("${dirbase}/$subdir");
	    $currentdir="$diry/$graph";
	}
    } else {
	$currentdir="$diry/$graph";
    }
}
unless (-e $currentdir) { 
    print "Please start: ./launch -p paramfile -t templatefile -n first. \n";
    exit;
}
$Nn=$hash1_var{"Nn"};
#############################################################             
$Nmin=1;
$Nlist[0]=$Nmin; #define it to get to *OUT.info file                 
#############################################################                 
#Option of choosing special primary sectors not necessary for                 
#primseclist entered by user at the moment, therefore:                        
#indflag is set to 0 by default. Maybe change later and if so                
#then here.                                                                   
#@Nlist = split(/,/,$hash1_var{"Nlist"});                                     
$indflag=1;
$infofile="$currentdir/${graph}Func$Nlist[0]OUT.info";
$lengthprimseclist=getinfo::lengthprimseclist($infofile);
##################################################################          
#define List of function numbers from 1 to highest number                     
#mentioned in primseclist put in by user                                       
@Nlist=($Nmin .. $lengthprimseclist);
$last=($lengthprimseclist-1);
$Nmax=$Nlist[$last];
##################################################################  
@multiplicities = split(/,/,$hash1_var{"multlist"});
#unless (@Nlist) {
#    $indflag=0;
#    @Nlist=($Nmin .. $Nmax);
unless (@multiplicities) {
    @multiplicities = (1,@Nlist);
}
#}
if(!@multiplicities){ die "Multiplicities must be specified if a list of sectors is specified" };

$epsord=$hash1_var{"epsord"};
$exe=$hash1_var{"exe"};
#$clusterflag=$hash1_var{"clusterflag"};
$nan=0;
#$notdoneflag=0;
if($indflag==0) {
    $itermax=0;
} else {
    $itermax=$last;
}
for ($iter=0;$iter<=$itermax;$iter++) {
    $cursec=$Nlist[$iter];
    $infofile="$currentdir/${graph}Func${cursec}OUT.info";
#    if($indflag==0){
#    $infofile="$currentdir/${graph}OUT.info"};
#    $declog="$currentdir/${graph}DecompositionSec${cursec}.log";
#    if($indflag==0){
    $declog="$currentdir/${graph}Decomposition.log";
#};
    unless (-e $infofile) {
	print "Warning - iterated sector decomposition not yet performed.\n";
	print "For more details, see $declog.\n"; 
	print "Launch the program via ./launch -p paramfile -t templatefile -n.\n"; 
	exit;
    }; 
    @polelist=getinfo::poles($infofile);
    $counter=0;
    foreach (@polelist) {
	$polestruct=$_;
	$counter++;
	if ($polestruct=~/(\d+)l(\d+)h(\d+)/){$i=$1;$j=$2;$h=$3};
#	if($indflag==1){
	$polestruct="func${cursec}P$polestruct";
#};
	if ($i+$j+$h>=-$epsord) {
	    $logflag=0;
	    $subexplog="$currentdir/$polestruct.log";
	    if (-s $subexplog) {$logflag=1};
	    if ($logflag==0) {
		print "Warning - pole structure $polestruct has not been executed.\n";
		print "Execute $currentdir/batch$polestruct,\nor submit $currentdir/job$polestruct to the batch system.\n"; 
		exit;
	    }
	}
    }
}
    
if($hash_var{"points"}){
    @points=split(/;/,$hash_var{"points"});
    system("perl -pi -e 's/^editor=.+/editor=none/g' $workingdir/$paramfile");
    $totpoints=@points;
    unless($linenumbers){$linenumbers=$totpoints};
    if($linenumbers<$totpoints){$totpoints=$linenumbers};
    if($flag==2){
	print "removing intermediate parameter files...\n";
    }elsif($flag==1){
	print "$totpoints points to collect results for...\n";
    }else{
	print "$totpoints points to calculate\n";
	system("perl -pi -e 's/^editor=.+/editor=none/g' $workingdir/$paramfile");
    }
    $counter=0; 
    foreach $point (@points) {
	if($counter<$totpoints){
	    $counter++;
	    $pointscalculated++;
	    $point=~s/^\./0\./;
	    @invars=split(/,/,$point);
	    $sij="sij=";$pi2="pi2=";$ms2="ms2=";
	    for($i=0;$i<$ninv;$i++){
		if($i<$nsij){
		    $sij="$sij,$invars[$i]";
		}elsif($i<$nsij+$npi2){
		    $pi2="$pi2,$invars[$i]";
		}else{
		    $ms2="$ms2,$invars[$i]";
		}
	    }
	    $sij=~s/,//;$pi2=~s/,//;$ms2=~s/,//;
	    #$pointname="pointname=$prefix$point";
	    $pointname="pointname=$prefix$pointscalculated";
            #   $pointvals="values=$point"; 
            #   $pointname=~s/,/_/g;
	    $pn=$pointname;
	    $pn=~s/pointname=//;
	    $plotstring="";
	    if($plotting){
		$xplotval="";
		foreach $xpi (@xplot){
		    $xplotval="${xplotval}SPACE$invars[$xpi]";
		}
		$xplotval=~s/SPACE//;
		$plotstring="-x $xplotval -f $prefix";
	    }
	    if($flag==1){
		print "collecting results for $pn...\n";
		#print `./resultsgeneral.pl -d $workingdir -p $pn$paramfile $plotstring`;
		system("./resultsgeneral.pl -d $workingdir -p $pn$paramfile $plotstring");
		if($?){die "Not all integrations for point $pn performed yet."};
	    }elsif($flag==2){
		`rm $workingdir/$pn$paramfile`;
	    }else{
		system("cp $workingdir/$paramfile $workingdir/$pn$paramfile");
		system("perl -pi -e 's/^sij=.+/$sij/g' $workingdir/$pn$paramfile");
		system("perl -pi -e 's/^pi2=.+/$pi2/g' $workingdir/$pn$paramfile");
		system("perl -pi -e 's/^ms2=.+/$ms2/g' $workingdir/$pn$paramfile");
		system("perl -pi -e 's/exeflag=.+/exeflag=4/g' $workingdir/$pn$paramfile");
		system("perl -pi -e 's/^pointname=.+/$pointname/g' $workingdir/$pn$paramfile");
		print "working on numeric point $pn...\n";
		system("./justnumericsgeneral.pl -d $workingdir -p $pn$paramfile $plotstring");
	    }
	}
    }
}


sub readmultiparams {
my $locparamfile=$_[0];
my $lines=0;
my %hash_varloc = ();
my @array_loc1=();
open (EREAD,$locparamfile) || die "cannot open $locparamfile";
while(<EREAD>) {
  chomp;
  s/^\s+//;
  unless (/^#/) {
    s/\s+//g; 
    if(m/^paramfile=(.*)/i){$hash_varloc{"paramfile"}=$1
    }
    elsif(/^lines=\s*(\d+)/){$hash_varloc{"lines"}=$1;
    }
    elsif(m/^numsij=(.*)/i){$hash_varloc{"numsij"}=$1
    }elsif(m/^numpi2=(.*)/i){$hash_varloc{"numpi2"}=$1
    }elsif(m/^numms2=(.*)/i){$hash_varloc{"numms2"}=$1
    }elsif(m/^xplot=(.*)/i){$hash_varloc{"xplot"}=$1
    }elsif(m/^pointname=(.*)/i){$hash_varloc{"pointname"}=$1
    }elsif(m/=/i){print "Warning - invalid assignment $_ in $locparamfile\n"
    }else{push (@array_loc1,$_)};
  }
}
if(@array_loc1){$hash_varloc{"points"}=join(';',@array_loc1)};
#if(@array_loc2){$hash_varloc{"values"}=join(';',@array_loc2)};
return %hash_varloc;
}

 
