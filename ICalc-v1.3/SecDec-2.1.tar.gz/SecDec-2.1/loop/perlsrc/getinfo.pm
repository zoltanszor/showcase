  # ****p* SecDec/loop/perlsrc/getinfo.pm
  #  NAME
  #    getinfo.pm
  #
  #  USAGE
  #  use getinfo 
  # 
  #  USES 
  #  various filenames parsed to its subroutines
  #
  #  USED BY 
  #  is called by finishnumericsloop.pl, finishnumericsgeneral.pl, justnumericsloop.pl, justnumericsgeneral.pl, 
  #  resultsloop.pl, resultsgeneral.pl, subexploop.pl, subexpgeneral.pl via getinfo::routinename(filename)
  #  
  #
  #  PURPOSE
  #  collects the subroutines which are used to read various pieces of information from output/intermediate files
  #    
  #  INPUTS
  #  arguments:
  #  infofile/logfile/graphfile/resfile: name of file where required information is held
  #
  #  RESULT
  #  the required piece of information is return from the subroutine
  #    
  #  SEE ALSO
  #  finishnumericsloop.pl, finishnumericsgeneral.pl, justnumericsloop.pl, justnumericsgeneral.pl, resultsloop.pl, 
  #  resultsgeneral.pl, subexploop.pl, subexpgeneral.pl, *Decomposition.log, [i]l[j]h[h].log, *x*.out, graph.m, 
  #  graphOUT.info
  #   
  #****
  #


package getinfo;



sub poles {
my $infofile=$_[0];
my @infolist=();
open (INFO,"<",$infofile);
 while (<INFO>){
  chomp;
  $a=$_;
  if ($a=~s/polesP(\d*l\d*h\d*) = //g){
   $t=$1;
   $a=~s/,//g;
   $a=~s/}//;
   $a=~s/{//;
   $a=~s/ //g;
   if($a>0){
    push(@infolist,$t)
   }
  }
 }
close INFO;
return @infolist
}

sub poleorders{
my $infofile=$_[0];
my @infolist=();
open (INFO,"<",$infofile);
 while(<INFO>) {
  chomp;
  if($_=~s/"(.+)functions = (.+)"//){
   if ($2 >0){push(@infolist,$1)}
  } 
 }
close INFO;
return @infolist
}

####### BEGIN ###################################################
# get information which functions f*.cc or f*.f
# at certain epsorder are independent of Feynman parameters
sub nbconsts {
    my $infofile=$_[0];
    my $ord=$_[1];
    open (INFO,"<",$infofile);
    while(<INFO>) {
	chomp;
	if($_=~s/"${ord}constants = (.+)"//){ $nbconst=$1; } 
    }
    close INFO;
    return $nbconst
}
####### END ######################################################

sub prefacord {
my $infofile=$_[0];
open (INFO,"<",$infofile);
 while (<INFO>){
  chomp;
  if ($_=~s/^prefacord =(.+)//){$prefacord=$1;$prefacord=~s/ //g}; 
 }
close INFO;
return $prefacord
}

   
sub prefac {
my $infofile=$_[0];
open (INFO,"<",$infofile);
 while (<INFO>){
  chomp;
  if ($_=~s/^prefac =(.+)//){$defaultpre=$1;$defaultpre=~s/ //g};
 }
close INFO;
return $defaultpre
}

sub expfu {
my $infofile=$_[0];
open (INFO,"<",$infofile);
 while (<INFO>){
  chomp;
  if ($_=~s/expoU =(.+)//){$expu=$1;$expu=~s/ //g};
  if ($_=~s/expoF =(.+)//){$expf=$1;$expf=~s/ //g};
 }
close INFO;
return ($expu,$expf)
}

sub lengthprimseclist {
my $infofile=$_[0];
open (INFO,"<",$infofile);
 while (<INFO>){
  chomp;
  if ($_=~s/^lengthprimseclist =(.+)//){$lengthprimseclist=$1;$lengthprimseclist=~s/ //g};
 }
close INFO;
return $lengthprimseclist
}


sub dim {
my $graphfile=$_[0];
open (GRAPH,"<",$graphfile);
 while (<GRAPH>){
  chomp;
  if ($_=~s/Dim=(.+)//){$dim=$1;$dim=~s/ //g;$dim=~s/;//g;last};
 }
close GRAPH;
if($dim eq "4-2eps]"){$dim="4-2*eps"}
return $dim
}

sub numint {
my $infofile=$_[0];
$numint=0;
open (INFO,"<",$infofile);
 while(<INFO>){
  chomp;
  if ($_=~s/Number of integrations = (.+)//){$numint=$1}
 }
close INFO;
return $numint
}

sub results {
    my $resfile=$_[0];
    $r1="error";$r2="error";$r3="error";$r4="failed";
    $exist=0;
    if(-e $resfile){$exist=1};
    if($exist){
	open (RES,"<",$resfile); 
	while (<RES>){
	    chomp;
	    if ($_=~s/result\s+=\s*(-*\w+\.*\w*\+*-*\w*)//){$r1=$1};
	    if ($_=~s/error\s+=\s+(\w+\.*\w*\+*-*\w*)//){$r2=$1};
	    if ($_=~s/CPUtime \(s\) =\s+(\w+\.*\w*\+*-*\w*)//){$r3=$1};
	    if ($_=~s/MaxErrorprob\s+=\s+(\w+\.*\w*\+*-*\w*)//){$r4=$1};
	}
	close RES;
	if( ($r1 eq "NaN") || ($r1 eq "nan") ) {
	    return $r1;
	} else {
	    return ($r1,$r2,$r3,$r4);
	}
    } else {
	return "nofile";
    }
}

sub resultsCmplx {
    my $resfile=$_[0];
    $r1="error";$r2="error";$r3="error";$r4="error";$r5="error"; $r6="failed";
    $exist=0;
    if(-e $resfile){$exist=1};
    if($exist){
	open (RES,"<",$resfile); 
	while (<RES>){
	    chomp;
	    if ($_=~s/result\s+=\s*(-*\w+\.*\w*\+*-*\w*)//){if($r1 eq "error"){$r1=$1}else{$r3=$1}};
	    if ($_=~s/error\s+=\s+(\w+\.*\w*\+*-*\w*)//){if($r2 eq "error"){$r2=$1}else{$r4=$1}};
	    if ($_=~s/CPUtime \(s\) =\s+(\w+\.*\w*\+*-*\w*)//){$r5=$1};
	    if ($_=~s/MaxErrorprob\s+=\s+(\w+\.*\w*\+*-*\w*)//){$r6=$1};
	}
	close RES;
	if($r1 eq "nan"){
	    return $r1;
	} else {
	    return ($r1,$r2,$r3,$r4,$r5,$r6);
	}
    } else {
	return "nofile";
    }
}

sub decotime {
my $logfile=$_[0];
open (LOG,"<",$logfile);
 while (<LOG>){
  chomp;
  if (~/Time taken to do the decomposition: (.+) secs/){$decotime=$1}
 }
close LOG;
return $decotime
}

sub subexptime {
my $logfile=$_[0];
open (LOG,"<",$logfile);
 while (<LOG>){
  chomp;
  if (~/Total time taken to produce .+ files: (.+) secs/){$subexptime=$1}
 }
close LOG;
return $subexptime
}

sub decwarning {
my $logfile=$_[0];
open (LOG,"<",$logfile);
 my $flag=0;
 while (<LOG>){
  chomp;
  if($_=~/Warning, F/){$flag=1}
 }
close LOG;
return $flag
}

1;
