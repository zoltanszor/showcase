  #****p* SecDec/loop/perlsrc/launchjob.pm
  #  NAME
  #    launchjob.pm
  #
  #  USAGE
  #  is called by subexploop.pl, subexpgeneral.pl, justnumericsloop.pl and justnumericsgeneral.pl, 
  #  polenumerics.pl, finishnumericsloop.pl and finishnumericsgeneral.pl, *subfile.pl
  # 
  #  USES 
  #  arguments parsed to submit
  #
  #  USED BY 
  #  subexploop.pl, subexpgeneral.pl, justnumericsloop.pl and justnumericsgeneral.pl, polenumerics.pl, 
  #  finishnumericsloop.pl and finishnumericsgeneral.pl, *subfile.pl
  #
  #  PURPOSE
  #  Uses appropriate syntax to submit a job to the desired batch system 
  #    
  #  INPUTS
  #  arguements:
  #  whichsystem: specifies which batch system is to be used
  #  jobfile: name of file to be submitted
  #
  #  RESULT
  #  subroutines can now be used by preparenumerics.pl
  #    
  #  SEE ALSO
  #  subexploop.pl, subexpgeneral.pl, justnumericsloop.pl and justnumericsgeneral.pl, polenumerics.pl, 
  #  finishnumericsloop.pl and finishnumericsgeneral.pl, *subfile.pl
  #****
  #

use strict;
package launchjob;

sub submit {
my $whichsystem=$_[0];
my $jobfile=$_[1];
if ($whichsystem==0){
submitdefault($jobfile)
} else {
submituserdefined($jobfile)
}
};

sub submitdefault {
my $jobfile=$_[0];
system("qsub -z $jobfile")
};


sub submituserdefined {
my $jobfile=$_[0];
##################################################
######### insert your own syntax here ############
##################################################
system("condor_submit $jobfile")
};
1;
