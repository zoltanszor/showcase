  #****p* SecDec/loop/perlsrc/makesum.pm
  #  NAME
  #    makesum.pm
  #
  #  USAGE
  #  is called from preparenumerics.pl via writefiles::makesum
  # 
  #  USES 
  #  arguements parsed from preparenumerics.pl
  #
  #  USED BY 
  #    
  #  preparenumerics.pl, writefiles.pm
  #
  #  PURPOSE
  #  writes the fortran files *sf*.f in the appropriate subdirectory
  #    
  #  INPUTS
  #  
  #  arguements:
  #  filename:name and directory of the *sf*.f to be written
  #  sumname:specifies the internal fortran name of the sum function
  #  lowii: number of the first function in the sum
  #  highii: number of the last function in the sum
  #  prestring: specifies the internal fortran name of the functions being summed ($[prestring]f1,...)
  #  variables: 
  #  funlist: is the list of functions to be summed, to be written to the external declaration
  #   part of *sf*.f
  #  asslist:consists of a string of "      g(#1)=[prestring]f#2(x)\n"
  #  lineflag: flag to decide whether a newline is needed in $funlist or $asslist
  #  nfun: number of functions being summed
  #  $sp: 6 space characters, useful for preparing the fortran format of *sf*.f
  #    
  #  RESULT
  #  new function *sf*.f in the appropriate subdirectory 
  #    
  #  SEE ALSO
  #  preparenumerics.pl, writefiles.pm
  #   
  #****
package makesum;

sub go {
my $filename=$_[0];
my $sumname=$_[1];
my $lowii=$_[2];
my $highii=$_[3];
my $prestring=$_[4];
my $sp="      ";
my $funlist="";
my $lineflag = 0;
my $asslist = "";
for ($ii=$lowii;$ii<=$highii;$ii++) {
    $lineflag++;
    if($ii==$highii) {
	$funlist = "$funlist\n     # ${prestring}f$ii\n";
    } elsif($lineflag >1) {
	$lineflag=0;
	$funlist = "$funlist\n     # ${prestring}f$ii,";
    } else {
	$funlist = "$funlist ${prestring}f$ii,";
    }
    my $gnum=$ii-$lowii+1;
    $asslist = "$asslist\n${sp}g($gnum) = ${prestring}f$ii(x)";
}#next ii
my $nfun=$highii-$lowii+1;
if(-e $filename) { system("rm -f $filename") };

open(SUMFILE, ">", "$filename");
print SUMFILE "${sp}double precision function $sumname(x)\n";
print SUMFILE "${sp}double precision x\n";
print SUMFILE "${sp}double precision g,sumg\n";
print SUMFILE "${sp}integer ndi\n";
print SUMFILE "${sp}common/mand/es0,es1,es2,es3,es4,es5,es6,es7,es8,es9\n";
#	print SUMFILE "     &  es6,es7,es8,es9,es10,es11,es12,es13,es14\n";
print SUMFILE "${sp}common/psq/esx1,esx2,esx3,esx4,esx5,esx6\n";
print SUMFILE "${sp}common/mas/em1,em2,em3,em4,em5,em6\n";
#maxinv should be called bi (biggest invariant) as it is shorter in the function files
print SUMFILE "${sp}common/maxinv/bi\n";
print SUMFILE "${sp}common/ndimen/ndi\n";
print SUMFILE "${sp}parameter (nfun=$nfun)\n";
print SUMFILE "${sp}dimension x(ndi),g(nfun)\n";
print SUMFILE "${sp}double precision$funlist";
print SUMFILE "${sp}$asslist\n";
print SUMFILE "${sp}sumg = 0.D0\n";
print SUMFILE "${sp}do k=1,nfun\n";
print SUMFILE "${sp}sumg = sumg+g(k)\n";
print SUMFILE "${sp}enddo\n";
print SUMFILE "${sp}$sumname = sumg\n";
print SUMFILE "${sp}return\n";
print SUMFILE "${sp}end";
close SUMFILE;
}
1;
