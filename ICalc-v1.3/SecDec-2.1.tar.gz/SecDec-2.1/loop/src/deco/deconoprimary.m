(*
#****m* SecDec/loop/src/deco/deconoprimary.m
# NAME
#  deconoprimary.m
# USAGE
#  called from subdir/graph/graph.m, via decomposegeneral.pl
# PURPOSE
#  performs the iterated sector decomposition using 
#  functions defined in primseclist in templatefile.m.
# RESULT
# [graph]sec*P*l*h*.out, graph*OUT.info written to subdir/graph, 
# SEE ALSO
#  NSDroutines.m
#****
*)

(* in Mathematica version >=8, decimal * 0 =0.(as decimal), whereas decimal * 0 = 0 (as
integer) for versions <8  *)

If[$VersionNumber>=8,                                                    
   Unprotect[MatchQ];                                                             
   MatchQ[aa_,0]:=MatchQ[N[aa],N[0]];                                          
   Protect[MatchQ]
   ];  

(*qlist is the list of sectors needing pre-decomposition to stop infinite recursion*)

(*load package which does the iterated sector decomposition *)
Get[StringJoin[path,ToString["src/deco/NSDroutines.m"]]];

(*old version: with sign change for all kinematic invariants
mandmin=Table[Table[sp[i,j]->-sp[i,j],{j,i+1,externalegs}],{i,externalegs-1}]//Flatten;
extmassmin=Table[ssp[i]->-ssp[i],{i,externalegs}];
 invarminusreps=Join[mandmin,extmassmin,{sp[i_,j_,k_]->-sp[i,j,k]}];
*)

decotime=AbsoluteTiming[
			(*Print["primseclist before=",primseclist];*)

			(*First search for position of the functions in primseclist which need sdiQnoprim called in qlist:*)
			qlist=Flatten[Position[primseclist[[#,1]]&/@Table[np,{np,1,Length[primseclist]}],#]&/@qlist];
			(*Then take complement of these found positions to get normal decomposition for functions not listed in qlist*)
			primlist=Complement[Table[np,{np,1,Length[primseclist]}],qlist];
			pprimseclist=primseclist[[#]]&/@primlist;
			
			If[MatchQ[qlist,{}]==False,
			   (*load package which decomposes squared Feynman parameters first*)
			   Get[StringJoin[path,ToString["src/deco/sdiQnoprim.m"]]];
			   qprimseclist=primseclist[[#]]&/@qlist;
			   qseclist=(Sequence@@sdiQ[#])&/@qprimseclist;
			   primseclist={Sequence@@qseclist,Sequence@@pprimseclist}
			   ,
			   primseclist=pprimseclist;
			   ];
			If[MatchQ[onshell,none]==False,primseclist=primseclist/.onshell];
			(*Print["primseclist after=",primseclist];*)
			decomposedsectors=IteratedNSDpack`IteratedNSD[primseclist];
			makeoutput;
			]; 

Print["\n"];
Print["Time taken to do the decomposition: ",decotime[[1]]," secs"];
