(*
  #****m* SecDec/loop/src/subexp/symbsub.m
  #  NAME
  #    symbsub.m
  #
  #  USAGE
  #  is run from subandexpand*l*h*.m
  # 
  #  USES 
  #  integrandfunctionlist prepared by formindlist.m
  #
  #  USED BY 
  #    
  #  subandexpand*l*h*.m
  #
  #  PURPOSE
  #  performs the symbolic subtraction of the integrand to regulate
  #  singularities in epsilon
  #    
  #  INPUTS
  #  
  #  integrandfunctionlist from formindlist.m
  #  n:number of propagators 
  #    
  #  RESULT
  #  The variables epspower[mu],numcoeff[mu],dset[mu] and exponents[mu,expodo]
  #  are calculated, corresponding to the subtracted integrand. These are then
  #  used by formfortran.m as inputs.
  #  
  #  SEE ALSO
  #  subandexpand*l*h*.m, formindlist.m, formfortran.m
  #   
  #****
*)
symbolicsubtraction=Module[{initialisetemplists,tempcoeff,tempset,tempexponents,tempepspower,
			    maxmu,findjexp,initialiseab,makenewtempexponents,makenewtempqtys,
			    makenewtemplists,setfinallists,makesymbolicintegrandlist},
  
  
 initialisetemplists:=Module[{txpd,initexpo},
			     Clear[tempcoeff,tempset,tempexponents,tempepspower];
			     tempcoeff[1,jexp]=1;
			     tempset[1,jexp]={};
			     
			     tempepspower[1,jexp]=0;
			     Do[
				If[txpd<jexp,initexpo=a[txpd]+b[txpd]*eps, initexpo=0];
				tempexponents[1,jexp,txpd]=initexpo
				,{txpd,feynpars}
				];
			     maxmu[jexp]=1;
			     ];
  
 findjexp:=Module[{expolist},
		  expolist=Join[integrandfunctionlist[[1,1]],{{-1}}]; (*1,1 enthaelt die Pole, ist kein Pol dabei, so bricht die Whileschleife bei -1 am Ende der expoliste ab*)
		  jexp=1; (*jexp findet also den Exponenten, bei dem zuerst ein Pol auftritt und markiert diesen Term damit dann*)
		  While[expolist[[jexp,1]]>-1,jexp++];
		  ];
  
 initialiseab:=Module[{at},
		      Clear[a,b];
		      Do[
			 at=integrandfunctionlist[[1,1,iabk,1]];
			 If[at<=-1,a[iabk]=at]
			 ,
			 {iabk,feynpars}
			 ];
		      ];
  
  
  
  makenewtempexponents[newexpo_,miflk_,mnewmu_,mnmu_]:=Module[{txd},
							      Do[
								 tempexponents[mnewmu,miflk+1,txd]=tempexponents[mnmu,miflk,txd]
								 ,{txd,feynpars}
								 ];
							      tempexponents[mnewmu,miflk+1,miflk]=tempexponents[mnewmu,miflk+1,miflk]+newexpo;
							      ];
  
  (*newexpo will be 0, a[iflk] + b[iflk]*eps or a[iflk] + b[iflk]*eps + i*)
  
  makenewtempqtys[mniflk_,mmu_]:=Module[{mtplr,abei,mntq,mntqi},
					Do[
					   Do[
					      newmu++;
					      tempepspower[newmu,mniflk+1]=tempepspower[mmu,mniflk];
					      tempset[newmu,mniflk+1]=Append[tempset[mmu,mniflk],{z[mniflk],mntqi}];
					      
					      mtplr=tempcoeff[mmu,mniflk]*(mntqi!)^-1;
					      abei=a[mniflk]+b[mniflk]*eps+mntqi;
					      If[
						 mntq==1
						 ,
						 tempcoeff[newmu,mniflk+1]=mtplr*(-1);
						 makenewtempexponents[abei,mniflk,newmu,mmu]
						 ,
						 If[
						    MatchQ[mntqi,-a[mniflk]-1]
						    ,
						    tempcoeff[newmu,mniflk+1]=mtplr*(b[mniflk]^-1);
						    tempepspower[newmu,mniflk+1]--
						    ,
						    tempcoeff[newmu,mniflk+1]=mtplr*((abei+1)^-1)
						    ];
						 makenewtempexponents[0,mniflk,newmu,mmu]
						 ]
					      
					      ,{mntqi,0,-a[mniflk]-1}
					      ]
					   ,{mntq,2}];
					];
  
  
  makenewtemplists[tiflk_]:=Module[{},
				   newmu=0;
				   Do[
				      makenewtempqtys[tiflk,mu];
				      newmu++;
				      tempepspower[newmu,tiflk+1]=tempepspower[mu,tiflk];
				      tempcoeff[newmu,tiflk+1]=tempcoeff[mu,tiflk];
				      tempset[newmu, tiflk+1]=tempset[mu,tiflk];
				      makenewtempexponents[a[tiflk]+b[tiflk]*eps,tiflk,newmu,mu];
				      ,{mu,maxmu[tiflk]}
				      ];
				   maxmu[tiflk+1]=newmu;
				   ];
  
  
 setfinallists:=Module[{expodo,mu},
		       Do[
			  epspower[mu]=tempepspower[mu,feynpars+1];
			  numcoeff[mu]=tempcoeff[mu,feynpars+1];
			  dset[mu]=tempset[mu,feynpars+1]; (*dset for derivative set*)
			  Do[
			     exponents[mu,expodo]=tempexponents[mu,feynpars+1,expodo]
			     ,{expodo,feynpars}
			     ];
			  ,{mu,maxmu[feynpars+1]}
			  ];
		       sizemu=maxmu[feynpars+1];
		       ];
  
  makesymbolicintegrandlist=Module[{},
				   
				   initialiseab;
				   findjexp;
				   initialisetemplists;
				   If[jexp<feynpars+1,
				      Do[
					 makenewtemplists[iflk]
					 ,
					 {iflk,jexp,feynpars} 
					 ];
				      setfinallists
				      ,
				      epspower[1]=0;
				      numcoeff[1]=1;
				      dset[1]={};
				      Do[
					 exponents[1,expondok]=a[expondok]+b[expondok]*eps
					 ,
					   {expondok,feynpars}
					 ];
				      sizemu=1;
				      ]
				   ];
  
  ](*end of symbolic subtraction*)
  
