(****************************************************************************)
(****************************************************************************)
(******* USER INPUT for construction of integrand ***************************)
(****************************************************************************)
(****************************************************************************)
(******* This example is for the massive two-loop vertex graph **************)
(****************************************************************************)
(****************************************************************************)
(******* Propagator powers and length ***************************************)
(* Fix Length of powerlist to number of propagators in the original diagram 
 you want to compute (automatically computes exponents of function U and F if 
 you do not specify them yourself in the primseclist. And you can give 
 propagator powers if different from one *)

nbofpropagators=6;
powerlist=Table[1,{i,nbofpropagators}];
(****************************************************************************)
(******* On-shell conditions (optional) *************************************)
(* give on-shell conditions, but PLEASE NOTE: in constructing F, 
         (pi+pj)^2 will automatically be called sp[i,j]; pi^2 will be 
         called ssp[i]; masses m_i^2 must be called ms[i]; *)

 onshell={ssp[1]->0,ssp[2]->0,sp[1,3]->0,sp[2,3]->0,ssp[3]->sp[1,2]};
(****************************************************************************)
(******* Set Dimension ******************************************************)
(* Dimension can be changed, but symbol for epsilon must remain the same *)

Dim=4-2*eps;
(****************************************************************************)
(****************************************************************************)
(****************************************************************************)
(****Specify the rank of the integral you want to compute in primseclist*****)
rank=0;
(*
 Specify here your functions. The Syntax is as follows: 
 {NumberOfFunction,{list of exponents},{{function U,exponent of U,decomposition flag},
      {function F,exponent of F,decomposition flag}},Numerator},
 where the decomposition flag should be chosen A if no further decomposition
 is needed and chosen B if further sector decomposition will be needed. XU and
 XF can be used if the exponents of functions U and F should be computed
 automatically according to the number of propagators (otherwise insert your 
 own exponent there instead), dimension and multiplicities (default is 1) 
 specified in the "myparamfile"
 *)
primseclist = {{5, {0, 0, 0, 0, 0, 0}, 
      {{t[2] + t[2]*t[3] + t[4] + t[2]*t[4] + t[3]*t[4] + t[5] + t[2]*t[5] + 
         t[3]*t[5] + t[1] + t[2]*t[1] + t[3]*t[1], XU, B}, 
       {ms[1]*t[2] + ms[1]*t[2]^2 + 2*ms[1]*t[2]*t[3] - ssp[3]*t[2]*t[3] + 
         ms[1]*t[2]^2*t[3] + ms[1]*t[2]*t[3]^2 + ms[1]*t[4] + 
         2*ms[1]*t[2]*t[4] + ms[1]*t[2]^2*t[4] + 2*ms[1]*t[3]*t[4] - 
         ssp[3]*t[3]*t[4] + 2*ms[1]*t[2]*t[3]*t[4] + ms[1]*t[3]^2*t[4] + 
         ms[1]*t[5] + 2*ms[1]*t[2]*t[5] + ms[1]*t[2]^2*t[5] + 
         2*ms[1]*t[3]*t[5] - ssp[3]*t[3]*t[5] + 2*ms[1]*t[2]*t[3]*t[5] - 
         ssp[3]*t[2]*t[3]*t[5] + ms[1]*t[3]^2*t[5] + ms[1]*t[1] + 
         2*ms[1]*t[2]*t[1] - ssp[3]*t[2]*t[1] + ms[1]*t[2]^2*t[1] + 
         2*ms[1]*t[3]*t[1] - ssp[3]*t[3]*t[1] + 2*ms[1]*t[2]*t[3]*t[1] + 
         ms[1]*t[3]^2*t[1] - ssp[3]*t[5]*t[1] - ssp[3]*t[2]*t[5]*t[1] - 
         ssp[3]*t[3]*t[5]*t[1], XF, B}}, 1}, {2, {0, 0, 0, 0, 0, 0}, 
      {{t[1] + t[3] + t[4] + t[1]*t[4] + t[3]*t[4] + t[5] + t[1]*t[5] + 
         t[3]*t[5] + t[2] + t[1]*t[2] + t[3]*t[2], XU, B}, 
       {ms[1]*t[1] + ms[1]*t[1]^2 + ms[1]*t[3] + 2*ms[1]*t[1]*t[3] - 
         ssp[3]*t[1]*t[3] + ms[1]*t[3]^2 + ms[1]*t[4] + 2*ms[1]*t[1]*t[4] + 
         ms[1]*t[1]^2*t[4] + 2*ms[1]*t[3]*t[4] + 2*ms[1]*t[1]*t[3]*t[4] - 
         ssp[3]*t[1]*t[3]*t[4] + ms[1]*t[3]^2*t[4] + ms[1]*t[5] + 
         2*ms[1]*t[1]*t[5] + ms[1]*t[1]^2*t[5] + 2*ms[1]*t[3]*t[5] - 
         ssp[3]*t[3]*t[5] + 2*ms[1]*t[1]*t[3]*t[5] - ssp[3]*t[1]*t[3]*t[5] + 
         ms[1]*t[3]^2*t[5] + ms[1]*t[2] + 2*ms[1]*t[1]*t[2] - 
         ssp[3]*t[1]*t[2] + ms[1]*t[1]^2*t[2] + 2*ms[1]*t[3]*t[2] + 
         2*ms[1]*t[1]*t[3]*t[2] - ssp[3]*t[1]*t[3]*t[2] + ms[1]*t[3]^2*t[2] - 
         ssp[3]*t[5]*t[2] - ssp[3]*t[1]*t[5]*t[2] - ssp[3]*t[3]*t[5]*t[2], 
        XF, B}}, 1}, {3, {0, 0, 0, 0, 0, 0}, 
      {{t[2] + t[1]*t[2] + t[4] + t[1]*t[4] + t[2]*t[4] + t[5] + t[1]*t[5] + 
         t[2]*t[5] + t[3] + t[1]*t[3] + t[2]*t[3], XU, B}, 
       {ms[1]*t[2] + 2*ms[1]*t[1]*t[2] - ssp[3]*t[1]*t[2] + 
         ms[1]*t[1]^2*t[2] + ms[1]*t[2]^2 + ms[1]*t[1]*t[2]^2 + ms[1]*t[4] + 
         2*ms[1]*t[1]*t[4] - ssp[3]*t[1]*t[4] + ms[1]*t[1]^2*t[4] + 
         2*ms[1]*t[2]*t[4] + 2*ms[1]*t[1]*t[2]*t[4] + ms[1]*t[2]^2*t[4] + 
         ms[1]*t[5] + 2*ms[1]*t[1]*t[5] - ssp[3]*t[1]*t[5] + 
         ms[1]*t[1]^2*t[5] + 2*ms[1]*t[2]*t[5] - ssp[3]*t[2]*t[5] + 
         2*ms[1]*t[1]*t[2]*t[5] + ms[1]*t[2]^2*t[5] + ms[1]*t[3] + 
         2*ms[1]*t[1]*t[3] - ssp[3]*t[1]*t[3] + ms[1]*t[1]^2*t[3] + 
         2*ms[1]*t[2]*t[3] + 2*ms[1]*t[1]*t[2]*t[3] - ssp[3]*t[1]*t[2]*t[3] + 
         ms[1]*t[2]^2*t[3] - ssp[3]*t[5]*t[3] - ssp[3]*t[1]*t[5]*t[3] - 
         ssp[3]*t[2]*t[5]*t[3], XF, B}}, 1}, {4, {0, 0, 0, 0, 0, 0}, 
      {{t[1] + t[2] + t[1]*t[2] + t[3] + t[2]*t[3] + t[1]*t[5] + t[2]*t[5] + 
         t[3]*t[5] + t[1]*t[4] + t[2]*t[4] + t[3]*t[4], XU, B}, 
       {ms[1]*t[1]^2 + 2*ms[1]*t[1]*t[2] + ms[1]*t[1]^2*t[2] + ms[1]*t[2]^2 + 
         ms[1]*t[1]*t[2]^2 + 2*ms[1]*t[1]*t[3] - ssp[3]*t[1]*t[3] + 
         2*ms[1]*t[2]*t[3] + 2*ms[1]*t[1]*t[2]*t[3] - ssp[3]*t[1]*t[2]*t[3] + 
         ms[1]*t[2]^2*t[3] + ms[1]*t[3]^2 + ms[1]*t[2]*t[3]^2 + 
         ms[1]*t[1]^2*t[5] + 2*ms[1]*t[1]*t[2]*t[5] + ms[1]*t[2]^2*t[5] + 
         2*ms[1]*t[1]*t[3]*t[5] - ssp[3]*t[1]*t[3]*t[5] + 
         2*ms[1]*t[2]*t[3]*t[5] - ssp[3]*t[2]*t[3]*t[5] + ms[1]*t[3]^2*t[5] + 
         ms[1]*t[1]^2*t[4] + 2*ms[1]*t[1]*t[2]*t[4] - ssp[3]*t[1]*t[2]*t[4] + 
         ms[1]*t[2]^2*t[4] + 2*ms[1]*t[1]*t[3]*t[4] - ssp[3]*t[1]*t[3]*t[4] + 
         2*ms[1]*t[2]*t[3]*t[4] + ms[1]*t[3]^2*t[4] - ssp[3]*t[1]*t[5]*t[4] - 
	ssp[3]*t[2]*t[5]*t[4] - ssp[3]*t[3]*t[5]*t[4], XF, B}}, 1},{1, {0, 0, 0, 0, 0, 0}, {{t[1] + t[2] + t[1]*t[2] + t[3] + t[2]*t[3] + 
         t[1]*t[4] + t[2]*t[4] + t[3]*t[4] + t[1]*t[5] + t[2]*t[5] + 
         t[3]*t[5], XU, B}, {ms[1]*t[1]^2 + 2*ms[1]*t[1]*t[2] + 
         ms[1]*t[1]^2*t[2] + ms[1]*t[2]^2 + ms[1]*t[1]*t[2]^2 + 
         2*ms[1]*t[1]*t[3] - ssp[3]*t[1]*t[3] + 2*ms[1]*t[2]*t[3] - 
         ssp[3]*t[2]*t[3] + 2*ms[1]*t[1]*t[2]*t[3] - ssp[3]*t[1]*t[2]*t[3] + 
         ms[1]*t[2]^2*t[3] + ms[1]*t[3]^2 + ms[1]*t[2]*t[3]^2 + 
         ms[1]*t[1]^2*t[4] + 2*ms[1]*t[1]*t[2]*t[4] + ms[1]*t[2]^2*t[4] + 
         2*ms[1]*t[1]*t[3]*t[4] - ssp[3]*t[1]*t[3]*t[4] + 
         2*ms[1]*t[2]*t[3]*t[4] + ms[1]*t[3]^2*t[4] - ssp[3]*t[1]*t[5] + 
         ms[1]*t[1]^2*t[5] - ssp[3]*t[2]*t[5] + 2*ms[1]*t[1]*t[2]*t[5] - 
         ssp[3]*t[1]*t[2]*t[5] + ms[1]*t[2]^2*t[5] - ssp[3]*t[3]*t[5] + 
         2*ms[1]*t[1]*t[3]*t[5] - ssp[3]*t[1]*t[3]*t[5] + 
         2*ms[1]*t[2]*t[3]*t[5] + ms[1]*t[3]^2*t[5], XF, B}}, 1}, 
     {6, {0, 0, 0, 0, 0, 0}, {{t[1] + t[2] + t[1]*t[2] + t[3] + t[2]*t[3] + 
         t[1]*t[4] + t[2]*t[4] + t[3]*t[4] + t[1]*t[5] + t[2]*t[5] + 
         t[3]*t[5], XU, B}, {ms[1]*t[1]^2 + 2*ms[1]*t[1]*t[2] - 
         ssp[3]*t[1]*t[2] + ms[1]*t[1]^2*t[2] + ms[1]*t[2]^2 + 
         ms[1]*t[1]*t[2]^2 + 2*ms[1]*t[1]*t[3] - ssp[3]*t[1]*t[3] + 
         2*ms[1]*t[2]*t[3] + 2*ms[1]*t[1]*t[2]*t[3] - ssp[3]*t[1]*t[2]*t[3] + 
         ms[1]*t[2]^2*t[3] + ms[1]*t[3]^2 + ms[1]*t[2]*t[3]^2 + 
         ms[1]*t[1]^2*t[4] + 2*ms[1]*t[1]*t[2]*t[4] + ms[1]*t[2]^2*t[4] + 
         2*ms[1]*t[1]*t[3]*t[4] - ssp[3]*t[1]*t[3]*t[4] + 
         2*ms[1]*t[2]*t[3]*t[4] + ms[1]*t[3]^2*t[4] - ssp[3]*t[1]*t[5] + 
         ms[1]*t[1]^2*t[5] - ssp[3]*t[2]*t[5] + 2*ms[1]*t[1]*t[2]*t[5] + 
         ms[1]*t[2]^2*t[5] - ssp[3]*t[3]*t[5] + 2*ms[1]*t[1]*t[3]*t[5] - 
         ssp[3]*t[1]*t[3]*t[5] + 2*ms[1]*t[2]*t[3]*t[5] - 
	 ssp[3]*t[2]*t[3]*t[5] + ms[1]*t[3]^2*t[5], XF, B}}, 1}};

(********************************************************************************************************************)  
